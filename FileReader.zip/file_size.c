#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
int file_size(FILE *fp) {

    int sz = 0;
    fseek (fp, 0L, SEEK_END);
    sz = ftell(fp);
    rewind(fp);
    return sz;
 }
/*==============================================================================*/
