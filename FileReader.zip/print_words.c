#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/

void print_words ( char **word_array){

  int i = 0;
  while (word_array[i] != NULL) {
          printf ("%s\n", word_array[i]);
          i++;
    }
    putchar('\n');

}
/*==============================================================================*/
