#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#define ENDOFALPHABET 26
#define FIRSTCHAR 0
/*==============================================================================*/
void free_alphabetical_array ( char ***alphabetical_array) {

  int letter = 0;
  int word = 0 ;

    for (letter = 0; letter < ENDOFALPHABET; letter++)  {
         while (alphabetical_array[letter][word] != NULL) {
                free(alphabetical_array[letter][word]);
             word++;
          }
         free(alphabetical_array[letter]);
         word = 0;
   }
    free(alphabetical_array);
}
/*==============================================================================*/
