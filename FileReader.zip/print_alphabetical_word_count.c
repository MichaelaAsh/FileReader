#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#define A 97   /* ascii value of common a */
#define Z 122 /* ascii value for common z */
/*==============================================================================*/
void print_alphabetical_word_count ( int *store_word_count) {

  char alphabet = A;
  int letter = 0;

  while (alphabet <= Z) {
        printf("%c = %d,", alphabet - 32, store_word_count[letter]);
        alphabet++;
        letter++;
     }
     putchar('\n');
     putchar('\n');
}
/*==============================================================================*/
