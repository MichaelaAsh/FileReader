#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#define A 97   /* ascii value of common a */
#define Z 122 /* ascii value for common z */
/*==============================================================================*/
int *alphabetical_word_count (char **word_array) {

  int row_check;
  char alphabet = A;
  int *store_word_count = malloc(sizeof(int)* 26); /* allocated memory so that we can return the array */
  int letter_increment = 0;
  int word_count = 0;

  while (alphabet <= Z) {
       word_count = 0; /* reintilaize at the beginning of each letter to count the matches*/
       for (row_check = 0; word_array[row_check] != NULL; row_check++) {
                         /* the column is always zero because it's the start of each word */
                         if (word_array[row_check][0] == alphabet || word_array[row_check][0] == alphabet - 32) {
                                                                /*alphabet-32 = UpperCase correponding letter */
                             word_count++;
                         }

          }
          store_word_count[letter_increment] = word_count;
          alphabet++;
          letter_increment++;

        }

    return store_word_count;

}
/*==============================================================================*/
