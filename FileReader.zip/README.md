## Program
This program reads in two file called a1_words.txt and a1_moreWords.txt that is in the
directory

## file_size:
find how many bytes are in a file

## read_words:
read the file

## print_words:
prints out each word on a newline in the exact order as the file
using print_words

## alphabetical_word_count:
stores the for each letter how many
words start with the corresponding letter

## print_alphabetical_word_count:
prints the results

## create_alphabetic_array:
each element corresponds with a letter
in the alphabet has all the words that start with that letter stored there

## print_alphabetical_array:
prints out the words stored in create_alphabetic_array

## Con to this program:

This program will not accurately detect the start of a word if the there is
punctuation marks is at the beginning of word and there is no space between.
For example: "The" when read in " is the start of the word therefore it will not
be read in as a word that start with T.
