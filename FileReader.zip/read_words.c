#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int file_size(FILE *fp);
/*==============================================================================*/
#define MAXLENGTH 46
/*==============================================================================*/
char **read_words (FILE *fp) {

  int i = 0;
  int size_of_file = file_size(fp)/2;
  char **words = malloc (sizeof (char *) *size_of_file);
  char line[MAXLENGTH];

   while (fscanf(fp, "%s" ,line ) != EOF) {
            words[i]= malloc (sizeof (char ) * MAXLENGTH);
            strcpy(words[i], line);
             i++;

  }

  words[i] = NULL;
  return words;

}

/*==============================================================================*/
