#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "alphabetical_printing.h"
/*The program reads in 2 files, prints outa list of word in the files, Secondly it prints
the alphabet and shows how many time the start of the words begins with the letter,
Lastly, it prints out the correponding words that  begin with those letter */

int main (int argc, char *argv[] ) {
  if (argc != 1) {
    printf("Usage: ./alphabetical_printing\n");
    exit(1);
  }

  FILE *fp;
  char **word_array; /*to store the word read from file */
  int *store_word_count; /* to storesthe number of times the start of a
   word matches a letter and stores it as an element per letter */
  char ***alphabet_array; /* to store the words that match for each alphabet */

/*==============================================================================*/
  if ( (fp = fopen("a1_words.txt", "r") ) != NULL ) { /* first file */
      word_array = read_words(fp);
      print_words(word_array);
      store_word_count = alphabetical_word_count(word_array);
      print_alphabetical_word_count(store_word_count);
      alphabet_array = create_alphabetic_array(word_array, store_word_count);
      print_words_alphabetically(alphabet_array);

  }  else  { /*error check */
            printf ( "Cannot open a1_text.txt" );
            return(-2);
  } /* end for the file open if statement */
  fclose (fp);
/*==============================================================================*/
  if ( (fp = fopen("a1_moreWords.txt", "r") ) != NULL ) {/*second file */
      word_array = read_words(fp);
      print_words(word_array);
      store_word_count = alphabetical_word_count(word_array);
      print_alphabetical_word_count(store_word_count);
      alphabet_array = create_alphabetic_array(word_array, store_word_count);
      print_words_alphabetically(alphabet_array);

  }  else  { /*error check */
            printf ( "Cannot open a1_moreWords.txt" );
            return(-2);
  } /* end for the file open if statement */
   fclose (fp);

/*==============================================================================*/
 return (0) ;

} /* end of code */
