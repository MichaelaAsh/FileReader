#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#define A 97   /* ascii value of common a */
#define Z 122 /* ascii value for common z */
#define ENDOFALPHABET 26
/*==============================================================================*/

void print_words_alphabetically(char ***alphabet_array) {
   int letter = 0;
   int word = 0;

   char upper_alphabet = A - 32; /* ASCII Value for UpperCase letters */
   char lower_alphabet = A;

 for (letter = 0; letter < ENDOFALPHABET; letter++)  {

     if (alphabet_array[letter][0] ==  NULL ) { /* checks if the array is empty for that letter */
       printf("'%c'\n",upper_alphabet+letter);
       printf("There are no words that begin with the letter '%c'\n", lower_alphabet+ letter);
       putchar('\n');
     } else {
       printf("'%c'\n", upper_alphabet+letter);
     }

      while (alphabet_array[letter][word] != NULL) {

              if (alphabet_array[letter][0] !=  NULL ) { /* if it's not empty it prints the word*/
                  printf ("%s\n", alphabet_array[letter][word]);
                }

          word++;
       }
     putchar('\n');
     word = 0;

   }

}
/*==============================================================================*/
