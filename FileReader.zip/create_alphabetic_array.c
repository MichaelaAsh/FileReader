#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*==============================================================================*/
#define MAXLENGTH 46
#define ENDOFALPHABET 26
#define A 97   /* ascii value of common a */
#define Z 122 /* ascii value for common z */
/*==============================================================================*/
char ***create_alphabetic_array (char **word_array, int *store_word_count) {

  char ***alphabetical_array = malloc(sizeof(char **) * 26); /*stores 26 array (for 26 letters)
                                                               and each array stores the words
                                                               that begin with the correponding letter */
  char letter = A;
  int i = 0;
  int j = 0;

  for (i = 0; i < ENDOFALPHABET; i++) {
    /* points to each letter in the array */
    alphabetical_array[i] = malloc(sizeof(char*) *(store_word_count[i] + 1));
    for (j = 0; j < (store_word_count[i] + 1); j++ ) {
      /* points to the words in the letter array */
      alphabetical_array[i][j] = malloc (sizeof(char) * MAXLENGTH);

    }

  }

  i = 0;
  int word = 0;
  int k = 0;
  #define FIRSTCHAR 0
  while (i < ENDOFALPHABET ) {
    word = 0;
    while (k < (store_word_count[i]+1) && *(word_array + word) != NULL) {

          if ( *(*(word_array + word) + FIRSTCHAR) == letter || *(*(word_array + word) + FIRSTCHAR) == letter - 32) {
                                                       /*letter - 32 = UpperCase correponding letter */
            strcpy (alphabetical_array[i][k],  *(word_array + word));
            k++;
          }

      word++;
    }
    letter++;
    alphabetical_array[i][k] = NULL;

    k = 0;

    i++;
  }


  return (alphabetical_array);
}
/*==============================================================================*/
