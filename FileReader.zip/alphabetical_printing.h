int file_size(FILE *fp);
char **read_words (FILE *fp);
void print_words ( char **word_array);
int *alphabetical_word_count (char **word_array);
void print_alphabetical_word_count ( int *store_word_count);
char ***create_alphabetic_array (char **word_array, int *store_word_count);
void free_alphabetical_array ( char ***alphabetical_array);
void print_words_alphabetically (char ***alphabet_array);
